package com.exam.security;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//ɨ�谲ȫ������İ�
@Configuration
@ComponentScan("com.exam.security")
public class MyProtectConfig {

}
