package com.exam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.entity.Exam;
import com.exam.entity.Question;
import com.exam.entity.Student;
import com.exam.service.QuestionService;
import com.exam.service.StudentExamService;

@RestController
@RequestMapping("/stuExam")
public class StudentExamController {
	@Autowired private StudentExamService ses;
	@Autowired private QuestionService qs;
	//����ȥ���Ե�ѧ������
	@RequestMapping("toExam")
	public List<Question> toExam(Student s,String eid){
		ses.toExam(s,eid);
		return ses.showPaper(s,eid);
	}
	@RequestMapping("/addQuestion")
	public Question addQuestion(Question q) {
		return qs.saveQuestion(q);
	}
	@RequestMapping("/addStudent")
	public Student addStu(Student s) {
		return ses.addStu(s);
	}
	//���ӿ���
	@RequestMapping("/addExam")
	public Exam addEx(Exam e) {
		return ses.addExam(e);
	}
	//��������
	@RequestMapping("/baoming")
	public String baoming(Student s,String eid) {
		ses.baoming(s, eid);
		return "success";
	}
	/*
	 * @RequestMapping("/commit") public String commit(Student s,String eid) {
	 * ses.commit(s, eid); return "success"; }
	 */
}
