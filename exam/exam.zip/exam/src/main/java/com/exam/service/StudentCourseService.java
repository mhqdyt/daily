package com.exam.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.dao.CourseDao;
import com.exam.dao.StudentCourseDao;
import com.exam.dao.StudentDao;
import com.exam.entity.Course;
import com.exam.entity.Exam;
import com.exam.entity.Student;
import com.exam.entity.Student_Course;

@Service
public class StudentCourseService {
    @Autowired private CourseDao cd;
	@Autowired private StudentDao sd;
	@Autowired private StudentCourseDao scd;
	//���ӿγ�
	public Course addCourse(Course c) {
		return cd.save(c);
	}
	
	//��ѯ���пγ�
	public List<Course> findAllCourse(){
		return cd.findAll();
	}
	
	//ѡ��
	public void xuanke(Student s,String course_id) {
		Course c=cd.findById(course_id).get();
		Student ss=sd.findById(s.getStudentId()).get();
		s.getCourses().add(c);
		Student_Course sc=new Student_Course();
		sc.setCourse_id(course_id);
		sc.setStudentId(s.getStudentId());
		scd.save(sc);
	}
	   public void baoming(Student s,String course_id) {
		   Course c=cd.findById(course_id).get();
		   Student ss=sd.findById(s.getStudentId()).get();
		   ss.getCourses().add(c);
		   sd.save(ss);
		 }
	
	
	//�鿴׼����Ϣ
			public List<Map<String ,Object>> findAllStudentCourse(Student stu) {

				List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
				List<Student_Course> StudentCourse=scd.findByStudentId(stu.getStudentId());
				for(Student_Course sc:StudentCourse) {
					Map<String,Object> map=new HashMap<String,Object>();
					map.put("stuName", stu.getStudentName());
					String course_id=sc.getCourse_id();
					Course c=cd.findById(course_id).get();
					map.put("course_name", c.getCourse_name());
					map.put("course_teacher", c.getCourse_teacher());
					map.put("course_id", course_id);
					map.put("course_class", c.getCourse_class());
					map.put("sid",stu.getStudentId());
					lists.add(map);
				}
				return lists;
			}


}
