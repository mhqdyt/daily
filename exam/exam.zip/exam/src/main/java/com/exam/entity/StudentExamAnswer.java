package com.exam.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name="student_exam_answer")
public class StudentExamAnswer {
	@Id
	@GeneratedValue(generator="qus")
	@SequenceGenerator(name="qus",allocationSize=1)
	private Integer stuExamAnswerId;
	@ManyToOne
	@JoinColumn(name="student_id")
	private Student student;
	@ManyToOne
	@JoinColumn(name="question_id")
	private Question question;
	private String answer;
	@ColumnDefault("0")
	private double score;
	@ManyToOne
	@JoinColumn(name="exam_id")
	private Exam exam;
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public Integer getStuExamAnswerId() {
		return stuExamAnswerId;
	}
	public void setStuExamAnswerId(Integer stuExamAnswerId) {
		this.stuExamAnswerId = stuExamAnswerId;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Exam getExam() {
		return exam;
	}
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	

}
