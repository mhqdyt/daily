package com.exam.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.exam.service.StudentService;
import com.exam.service.UserService;

//��ȫ��������
@EnableWebSecurity
public class ExamSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private UserService us;
	@Autowired
	private PasswordEncoder pe;
	@Autowired private StudentService ss;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
//		auth.userDetailsService(ss).passwordEncoder(pe);
		auth.userDetailsService(us).passwordEncoder(pe);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http.authorizeRequests().antMatchers("/regix","/preregix").permitAll()//"/regix","/preregix"
		.antMatchers("/admin/**").hasAuthority("ADMIN")
		.antMatchers("/teacher/**").hasAuthority("TEACHER")
		.antMatchers("/student/**").hasAuthority("STUDENT");
		http.formLogin();
		http.csrf().disable();
	}

}
