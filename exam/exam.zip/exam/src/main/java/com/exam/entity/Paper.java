package com.exam.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="tal_paper")
public class Paper {
	@Id
	private String paperId;
	@ManyToMany(cascade=CascadeType.PERSIST)
	@JoinTable(name="make_paper",
	joinColumns=@JoinColumn(name="paper_id"),
	inverseJoinColumns=@JoinColumn(name="question_id"))
	private List<Question> questions;
	public String getPaperId() {
		return paperId;
	}
	public void setPaperId(String paperId) {
		this.paperId = paperId;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	

}
