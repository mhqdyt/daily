package com.exam.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.exam.entity.Question;

public  interface QuestionDao extends JpaRepository<Question, Integer> {
	//ֱ�Ӵ����ݿ��в�����
		@Query(value="select * from tal_question limit ?1,1",nativeQuery=true)
		public Question findByRecordNo(int x);

}
