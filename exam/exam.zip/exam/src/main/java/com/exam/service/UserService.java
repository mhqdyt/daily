package com.exam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.exam.dao.UserRespo;
import com.exam.entity.User;
@Service
  
public class UserService implements UserDetailsService {
    @Autowired UserRespo userDao;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return userDao.getOne(username);
	}
	public void addUser(User u) {
		userDao.save(u);
	}

}
