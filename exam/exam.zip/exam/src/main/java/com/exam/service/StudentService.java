package com.exam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Service;

import com.exam.dao.StudentDao;
import com.exam.entity.Student;

@Service
public class StudentService implements UserDetailsService{
	@Autowired
	private StudentDao sd;
	
	public Student findByStuIdAndStuName(String stuId,String stuName) {
		return sd.findByStudentIdAndStudentName(stuId, stuName);
	}
	
	
	public String findById(String id,String name) {
		return sd.findByIdAndName(id, name);
	}
	
	//����ѧ��
		public Student addStu(Student s) {
			return sd.save(s);
		}


		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			// TODO Auto-generated method stub
			Student s= sd.findByStudentName(username);
			if(s==null) {
				//�ڴ�����
				
				InMemoryUserDetailsManager iud=new InMemoryUserDetailsManager();
				return iud.loadUserByUsername(username);
			}
			return s;
//			return sd.getOne(username);
			
		}

}
