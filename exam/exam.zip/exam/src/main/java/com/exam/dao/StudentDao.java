package com.exam.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.exam.entity.Student;

public interface StudentDao extends JpaRepository<Student, String> {
	@Query("select studentName from Student where studentId=?1 and studentName=?2")
	public String findByIdAndName(String id,String name);
//	@Query("select student from Student student where student.studentId=?2 and student.studentName=?1")
	
	public Student findByStudentIdAndStudentName(String studentId,String studentName);

	public Student findByStudentName(String name);

}
