package com.exam.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.exam.entity.Course;
import com.exam.entity.Exam;
import com.exam.entity.Student;
import com.exam.service.StudentCourseService;
import com.exam.service.StudentExamService;
import com.exam.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private StudentExamService ses;
	@Autowired
	private StudentService ss;
	@Autowired
	private StudentCourseService scs;

	// չʾ���еĿγ�
	@RequestMapping("/showAllCourses")
	public String showAllCourse(Model m) {
		List<Course> list = scs.findAllCourse();
		m.addAttribute("courses", list);
		return "student/courses";
	}

	// ѡ��
	@RequestMapping("/xuanke")
	@ResponseBody
	public String xuanke(String course_id, HttpServletRequest req) {
		Object o = req.getSession().getAttribute("student");
		if (o == null)
			return "failsure";
		Student s = (Student) o;
		scs.baoming(s, course_id);
		return "success";
	}

	// ��ʾѧ���α�
	@RequestMapping("/showStudentCourse")
	@ResponseBody
	public List<Map<String, Object>> showAllStudentCourse(HttpServletRequest req) {
		Student s = (Student) req.getSession().getAttribute("student");
		List<Map<String, Object>> lists = scs.findAllStudentCourse(s);
		if (lists.size() == 0)
			return null;
		return lists;
	}

	// ����ѧ��//�������ѧ����Ϣ��ʾ����
	// ������
	@RequestMapping("/regist")
	public String showStudent(Student stu, @RequestParam("stuphoto") MultipartFile photo, Model model)
			throws Exception {
		// photo�ֽ��������ͣ����ϴ����ļ���photo
		stu.setPhoto(photo.getBytes());
		ss.addStu(stu);
		return "student/index";
	}

	// ��¼
	// �Ӳ���
	@RequestMapping("/realLogin")
	@ResponseBody
	public String login(String stuId, String stuName, HttpServletRequest req) {
		Student stu = ss.findByStuIdAndStuName(stuId, stuName);
		req.getSession().setAttribute("student", stu);
		return stu.getStudentName();
	}

	// ��ʾ���п�����Ϣ
	@RequestMapping("/showAllExams")
	public String showAllExam(Model m) {
		List<Exam> list = ses.findAllExam();
		m.addAttribute("exams", list);
		return "student/exams";
	}

	// ����
	@RequestMapping("/baoming")
	@ResponseBody
	public String baoming(String examId, HttpServletRequest req) {
		Object o = req.getSession().getAttribute("student");
		if (o == null)
			return "failsure";
		Student s = (Student) o;
		ses.baoming(s, examId);
		return "success";
	}

	// ��ʾѧ��������Ϣ
	@RequestMapping("/showStudentExam")
	@ResponseBody
	public List<Map<String, Object>> showAllStudentExam(HttpServletRequest req) {
		Student s = (Student) req.getSession().getAttribute("student");
		List<Map<String, Object>> lists = ses.findAllStudentExam(s);
		if (lists.size() == 0)
			return null;
		return lists;
	}

	// ȥ����
	@RequestMapping("/toExam")
	public String toExam(String eid, HttpServletRequest req, Model m) {
		Student s = (Student) req.getSession().getAttribute("student");
		ses.toExam(s, eid);
		m.addAttribute("questions", ses.showPaper(s, eid));
		req.getSession().setAttribute("examId", eid);
		/* return "student/toExam"; */
		return "student/toExamPage";
	}

	// �ύ��
	/*
	 * @RequestMapping("/submit")
	 * 
	 * @ResponseBody public String submitPaper(HttpServletRequest req,@RequestBody
	 * List<Map<String, Object>> answers) {//@RequestBody :�������Ϊjson���� String s="";
	 * System.out.print("nihao"); Student
	 * stu=(Student)req.getSession().getAttribute("student"); String
	 * eid=(String)req.getSession().getAttribute("examId"); ses.commit(stu, eid,
	 * answers); System.out.print("nihao2"); //ɾ��׼����Ϣ
	 * ses.updateStuExam(stu.getStudentId(), eid); System.out.print("nihao3");
	 * return "�����ɹ���"; }
	 */
	@PostMapping(value="/submit",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String submitPaper(HttpServletRequest req,@RequestBody List<Map<String, Object>> answers) {
		Student stu=(Student)req.getSession().getAttribute("student");
		String eid=(String)req.getSession().getAttribute("examId");
		ses.commit(stu, eid, answers);
		//ɾ��׼����Ϣ
		ses.updateStuExam(stu.getStudentId(), eid);
		return "�����ɹ�";
	}

	// ���ܳɼ�
	@PostMapping("/getScore")
	@ResponseBody
	public double getScore(String sid, String eid) {
		return ses.sunScore(sid, eid);
	}

	@RequestMapping("/index")
	public String index(HttpServletRequest req) {
		Authentication au = SecurityContextHolder.getContext().getAuthentication();
		if (au.getPrincipal() instanceof Student) {
			Student s = (Student) au.getPrincipal();
			req.getSession().setAttribute("student", s);
		}
		return "student/index";
	}

	@RequestMapping("/beforeRegix")
	public String br() {
		return "student/regix";
	}

	@RequestMapping("/regix")
	public String addStudent(@Valid Student stu, BindingResult br, @RequestParam("stuphoto") MultipartFile photo,
			Model model) throws Exception {
		if (br.hasErrors()) {
			Map<String, String> errors = new HashMap<String, String>();
			if (br.hasFieldErrors("studentId")) {
				errors.put("stuIdError", br.getFieldError("studentId").getDefaultMessage());
			}
			if (br.hasFieldErrors("studentName")) {
				errors.put("stuNameError", br.getFieldError("studentName").getDefaultMessage());
			}
			model.addAttribute("es", errors);
			return "admin/regix";

		}
		if (photo == null || photo.getBytes().length == 0) {
			throw new Exception("ͼƬ����ṩ����");
		}
		stu.setPhoto(photo.getBytes());
		ses.addStu(stu);
		return "student/index";
	}

}
