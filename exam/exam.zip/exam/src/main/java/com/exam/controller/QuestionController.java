package com.exam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.exam.dao.StudentDao;
import com.exam.entity.Question;
import com.exam.entity.Student;
import com.exam.service.QuestionService;

@Controller
@RequestMapping("question")
public class QuestionController {
	@Autowired private QuestionService qs;
	@Autowired private StudentDao sd;
	
	//��ѯ����ѧ��
		@RequestMapping("/findall")
		public String findall(Model m) {
			List<Student>lists=sd.findAll();
			m.addAttribute("students",lists);
			return "templates/show";
		}
		
		//��������
		@RequestMapping("/addQuestion")
		public String add() {
			return "question/addQuestion";
		}
		//�����������
		@RequestMapping("/realaddQuestion")
		public String addReal(Question q,Model m) {
			qs.saveQuestion(q);
			m.addAttribute("questions",qs.findAll());
			return "question/showQuestion";
		}
		//��ҳ��ʾ����
		@RequestMapping("/showpage")
		public String showPage(int page,int size,Model m) {
			Page<Question> pageques=qs.findAll(page, size);
			m.addAttribute("curPage",pageques);
			return "question/showpage";
		}

}
