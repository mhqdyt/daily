package com.exam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.exam.entity.Student;
import com.exam.service.StudentService;

@Controller
public class RegistController {
	@Autowired private StudentService ss;
	
	
	// ����ѧ��//�������ѧ����Ϣ��ʾ����
		@RequestMapping("/studentregist")
		public String addStudent(Student stu, @RequestParam("stuphoto") MultipartFile photo, Model model) throws Exception {
			// photo�ֽ��������ͣ����ϴ����ļ���photo
			stu.setPhoto(photo.getBytes());
			BCryptPasswordEncoder pe=new BCryptPasswordEncoder();
			String pass=pe.encode(stu.getPassword());
			stu.setPassword(pass);
			ss.addStu(stu);
			return "student/index";
		}	
		

}
