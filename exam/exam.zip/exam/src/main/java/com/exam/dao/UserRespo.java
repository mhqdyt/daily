/**
 * 
 */
package com.exam.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.entity.User;

/**
 * @author 11487
 *
 */
public interface UserRespo extends JpaRepository<User, String> {

}
