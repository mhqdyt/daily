package com.exam.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.exam.dao.RoleDao;
import com.exam.entity.User;
import com.exam.service.UserService;

@Controller
/* @RequestMapping("/student") */
public class StudentControllerSecurity {
	@Autowired UserService us;
	@Autowired RoleDao rd;
	@Autowired PasswordEncoder pe;
	@RequestMapping("/student/showStudent")
	@ResponseBody
	public String s() {
		return "nihao,student";
	}
	
	@RequestMapping("/admin/showAdmin")
	@ResponseBody
	public String a() {
		return "nihao,admin";
	}
	
	@RequestMapping("/teacher/showTeacher")
	@ResponseBody
	public String t() {
		return "nihao,teacher";
	}
	
	@RequestMapping("/regix")
	@ResponseBody
	public String regix(String username,String password,String role) {
		User u=new User();
		u.setPassword(pe.encode(password));
		u.setUsername(username);
		u.getRoles().add(rd.getOne(role));
		us.addUser(u);
		return "success";
			
	}
	
	@RequestMapping("/preregix")
	public String pre_regix() {
		return "security/regix";
	}

}
