package com.exam.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.exam.entity.Student_Exam;
import com.exam.entity.Student_Exam_Keys;
@Repository
public interface StudentExamDao extends JpaRepository<Student_Exam, Student_Exam_Keys> {
	
	@Transactional
	@Modifying
	@Query("update Student_Exam se set se.paper.paperId=?1 where se.studentId=?2 and se.examId=?3")
	public int updatePapeId(String pid,String sid,String eid);
	
	public List<Student_Exam> findByStudentId(String sId);
	@Transactional
	@Modifying
	@Query("update Student_Exam se set se.flag=?3 where se.studentId=?1 and se.examId=?2")
	public int updateFlag(String sid,String eid,int flag);
	
	@Transactional
	@Modifying
	@Query("update Student_Exam se set se.score=?3 where se.studentId=?1 and se.examId=?2")
	public int updateScore(String sid,String eid,double score);

}
