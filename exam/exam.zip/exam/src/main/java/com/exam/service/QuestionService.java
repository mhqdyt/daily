package com.exam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.exam.dao.QuestionDao;
import com.exam.entity.Question;

@Service
public class QuestionService {
	
	@Autowired private QuestionDao qd;

	/* �������� */
	public Question saveQuestion(Question q) {
		return qd.save(q);
	}
	public List<Question> findAll(){
		return qd.findAll();
	}
	public Page<Question> findAll(int page,int size){
		return qd.findAll(PageRequest.of(page, size));
	}
}
