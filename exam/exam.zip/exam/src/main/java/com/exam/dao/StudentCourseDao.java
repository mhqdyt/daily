package com.exam.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.entity.Student_Course;
import com.exam.entity.Student_Course_Keys;

public interface StudentCourseDao extends JpaRepository<Student_Course, Student_Course_Keys> {
	
	public List<Student_Course> findByStudentId(String sId);

}
