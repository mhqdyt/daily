package com.exam.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.dao.ExamDao;
import com.exam.dao.PaperDao;
import com.exam.dao.QuestionDao;
import com.exam.dao.StudentDao;
import com.exam.dao.StudentExamAnswerDao;
import com.exam.dao.StudentExamDao;
import com.exam.entity.Exam;
import com.exam.entity.Paper;
import com.exam.entity.Question;
import com.exam.entity.Student;
import com.exam.entity.StudentExamAnswer;
import com.exam.entity.Student_Exam;

@Service
public class StudentExamService {
	@Autowired private ExamDao ed;
	@Autowired private PaperDao pd;
	@Autowired private QuestionDao qd;
	@Autowired private StudentExamDao sed;
	@Autowired private StudentDao sd;
	@Autowired private StudentExamAnswerDao sead;
	
	//�������
	private List<Question> findQuestion(int sum){
		List<Question> ques=new ArrayList<Question>();
		int allRecords=(int)qd.count();//�ܼ�¼��
		int recordNo[]=new int[sum];
		java.util.Random ran=new java.util.Random();
		for(int i=0;i<sum;i++) {
			int ranNo;
			while(true) {
				boolean flag=true;
				ranNo=ran.nextInt(allRecords);
				for(int j=0;j<i;j++) {
					if(recordNo[j]==ranNo) {
						flag=false;
						break;
					}
				}
				if(flag) break;
			}
			recordNo[i]=ranNo;
		}
		for(int i=0;i<sum;i++) {
			ques.add(qd.findByRecordNo(recordNo[i]));
		}
		return ques;
	}
	
	/* ���ӿ��� */
	public Exam addExam(Exam e) {
		return ed.save(e);
	}
	
	/* ���� */
	public void baoming(Student s,String exam_id) {
		Exam e=ed.findById(exam_id).get();
		Student ss=sd.findById(s.getStudentId()).get();
		s.getExams().add(e);
		Student_Exam see=new Student_Exam();
		see.setExamId(exam_id);
		see.setStudentId(s.getStudentId());
		sed.save(see);
	}

	/* ȥ���� */
	public void toExam(Student s,String eid) {
		String paperId="p_"+s.getStudentId()+""+eid;
		Paper paper=new Paper();
		paper.setPaperId(paperId);
		List<Question> qus=findQuestion(2);
		paper.setQuestions(qus);
		Student_Exam see=new Student_Exam();
		/*
		 * see.setExamId(eid); see.setStudentId(s.getStudentId()); see.setPaper(paper);
		 * sed.save(see);
		 */
		pd.save(paper);
		sed.updatePapeId(paperId, s.getStudentId(), eid);
		
		
	}

	/* ��ʾ�Ծ� */
	public List<Question> showPaper(Student s,String eid){
		String paperId="p_"+s.getStudentId()+""+eid;
		return pd.findQuestionsById(paperId);
	}
	
	//�����ύ���Դ�
		public void commit(Student s,String eid,List<Map<String,Object>> answers) {
			//ͨ�����Ե�ID�ÿ�����Ϣ
			Exam exam=ed.getOne(eid);
			//����ѧ����
			for(Map<String,Object> map:answers) {		
				StudentExamAnswer sea=new StudentExamAnswer();
				sea.setStudent(s);
				sea.setExam(exam);
				sea.setScore(-1);
//				String id=(String)map.get("queBaseNo");
//				Question q=questionDao.getOne(Integer.parseInt(qid));
//				sea.setQuestion(q);
//				sea.setAnswer((String)(map.get("queAnswer")));

			    Integer qid=(Integer)(map.get("questionId")); 
			    Question q=qd.getOne(qid);
			 
				sea.setQuestion(q);
				sea.setAnswer((String)map.get("answer"));
				sead.save(sea);
			}
		}
		
		//��ѯ����ѧ��
		public List<Student> findAllStudents(){
			return sd.findAll();
		}
		
		//�鿴���п���
		public List<Exam> findAllExam(){
			return ed.findAll();
		}
	
		//�鿴׼����Ϣ
		public List<Map<String ,Object>> findAllStudentExam(Student stu) {
			List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();
			List<Student_Exam> StudentExam=sed.findByStudentId(stu.getStudentId());
			for(Student_Exam se:StudentExam) {
				Map<String,Object> map=new HashMap<String,Object>();
				map.put("stuName", stu.getStudentName());
				String examId=se.getExamId();
				Exam e=ed.findById(examId).get();
				map.put("examDate", e.getExamDate());
				map.put("examPlace", e.getExamPlace());
				map.put("examId", examId);
				map.put("flag",se.getFlag());
				map.put("sid",stu.getStudentId());
				lists.add(map);
			}
			return lists;
		}
	
		//����׼����Ϣ
		public void updateStuExam(String sid,String eid) {
			sed.updateFlag(sid, eid, 1);
		}
	
		//��ѯ����ѧ���Ĵ�
		public List<StudentExamAnswer> findAllStuAnswer(){
			List<StudentExamAnswer> lists=sead.findAll();
			//���û�����ĵ�����
			List<StudentExamAnswer> seas=new ArrayList<StudentExamAnswer>();
			//�������У��ҳ�û���ĵ�����
			for(StudentExamAnswer sea:lists) {
				//����-1����û���ĵ�
				if(sea.getScore()==-1) {
					seas.add(sea);	
				}
			}
			return seas;
		}
		
		//�����ύ�ɼ�
		public void giveScore(List<Map<String,Object>> gs) {
			//�����ó�һ���������
			for(Map<String,Object> map:gs) {
				//�õ�����������
				Integer queId=Integer.parseInt((String)(map.get("questionId")));
				String eid=(String)(map.get("examId"));
				String sid=(String)(map.get("stuId"));
				double score=Double.parseDouble((String)(map.get("score")));
				sead.updateScore(sid, eid, queId, score);
			}
		}
		
		//�����ܳɼ�
		public double sunScore(String sid,String eid) {
			double score=0;
			//�ӿ��Դ����õ÷�
			List<StudentExamAnswer> lists=sead.findByStudentIdAndExamId(sid, eid);
			//�����õ��ɼ�
			for(StudentExamAnswer sea:lists) {
				if(sea.getScore()==-1) {
					score=-1;
					break;
				}
				score+=sea.getScore();
						
			}
			return score;
		}
	
	

	public Student addStu(Student s) {
		// TODO Auto-generated method stub
		return sd.save(s);
	}


	/*
	 * public void commit(Student s,String eid) { String
	 * paperId="p_"+s.getStudentId()+""+eid; Exam e=ed.findById(eid).get();
	 * List<Question> lists=pd.findQuestionsById(paperId); for(Question q:lists) {
	 * StudentExamAnswer sea=new StudentExamAnswer(); sea.setAnswer("I don't know");
	 * sea.setExam(e); sea.setStudent(s); sea.setQuestion(q); sead.save(sea); } }
	 */


	


}
