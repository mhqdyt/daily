package com.exam.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Proxy(lazy=false)
@Entity
@Table(name="tal_student")
public class Student implements UserDetails{
	
	private static final long serialVersionUID = 1L;
	
	@Id  //����������
	private String studentId;
	private String studentName;
	@ManyToOne
	@JoinColumn(name="roleId")
	private Role role;
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	private String password;
	@Lob
	@Column(name="student_photo",columnDefinition="longblob",nullable=true)
	//��MySQL���ݿ������������,����Ϊ��
	private byte[] photo;
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name="student_exam",
	   joinColumns=@JoinColumn(name="student_id"),
	   inverseJoinColumns=@JoinColumn(name="exam_id")	
			)
	private List<Exam> exams;
	
	@ManyToMany
	@JoinTable(name="student_course",
	   joinColumns=@JoinColumn(name="student_id"),
	   inverseJoinColumns=@JoinColumn(name="course_id")
	)
	private List<Course> courses;
	
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public List<Exam> getExams() {
		return exams;
	}
	public void setExams(List<Exam> exams) {
		this.exams = exams;
	}
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	//��̬����Ȩ��
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		List<SimpleGrantedAuthority> authors=new ArrayList<>();
		SimpleGrantedAuthority ags=new SimpleGrantedAuthority("STUDENT");
		authors.add(ags);
		return authors;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return studentName;
	}
	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	public Student() {

	}
	public Student(String studentId, String studentName, byte[] photo, List<Exam> exams) {

		this.studentId = studentId;
		this.studentName = studentName;
		this.photo = photo;
		this.exams = exams;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
