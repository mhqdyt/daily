package com.exam.controller;

public class MySecurityConfig {

//	@Autowired StudentService studentService; extends WebSecurityConfigurerAdapter 
//	@Autowired private PasswordEncoder pe;
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/studentbeforeRegist","studentregist").permitAll()
//		.antMatchers("/student/**").hasAuthority("STUDENT")
//		.antMatchers("/admin/**").hasRole("ADMIN");
//		http.formLogin().successForwardUrl("/student/index");
//	
//	}
//
//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		// TODO Auto-generated method stub
//		
//		//��studentService������֤
//		auth.userDetailsService(studentService).passwordEncoder(pe);
//		auth.inMemoryAuthentication().withUser("admin").password(pe.encode("123456")).roles("ADMIN");
//	}



}
