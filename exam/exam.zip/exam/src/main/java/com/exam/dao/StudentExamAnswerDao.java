package com.exam.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.exam.entity.StudentExamAnswer;

public interface StudentExamAnswerDao extends JpaRepository<StudentExamAnswer, Integer> {
	@Transactional //������
	@Modifying
	@Query("update StudentExamAnswer sea set sea.score=?4 where sea.question.questionId=?3 and sea.exam.examId=?2 and sea.student.studentId=?1")
	public void updateScore(String sid,String eid,Integer qid,double score);
	
	@Query("select sea from  StudentExamAnswer sea  where sea.student.studentId=?1 and sea.exam.examId=?2")
	public List<StudentExamAnswer> findByStudentIdAndExamId(String sid,String eid);
}
