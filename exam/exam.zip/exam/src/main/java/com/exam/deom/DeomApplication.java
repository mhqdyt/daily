package com.exam.deom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Import;

import com.exam.controller.ExamConfig;
import com.exam.security.MyProtectConfig;

@SuppressWarnings("unused")

@EntityScan("com.exam.entity") 
//@Import(ExamConfig.class)
@Import({MyProtectConfig.class,ExamConfig.class})
@SpringBootApplication(exclude=DataSourceAutoConfiguration.class)
public class DeomApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DeomApplication.class, args);	
	}


}
